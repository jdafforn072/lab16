var lyrics = ["This is how we do it",
                "Who are you? Oo O, Oo O",
                "Push it", 
                "I saw the sign"];

module.exports= lyrics;
